var mongoose = require('mongoose');
var TeamMember = require('./teamMember');
var Schema = mongoose.Schema;
var Location = require('./location');
var TeamMember = require('./teamMember');
var User = require('./user');
var Phase = require('./phase');

var teamScheme = mongoose.Schema({
  name: { type: String, required: true },
  long_name: String,
  initials: String,
  logo: String,
  coach: { type: Schema.Types.ObjectId, ref: 'TeamMember' },
  location: { type: Schema.Types.ObjectId, ref: 'Location' },
  phases: [{ type: Schema.Types.ObjectId, ref: 'Phase' }],
  coders: [{ type: Schema.Types.ObjectId, ref: 'User' }],
});

var Team = mongoose.model('Team', teamScheme);

exports.create = function (params, cb) {
  var team = new Team(params);

  Team.find({ $or: [{ name: team.name }] }, function (err, found) {

    if (found.length > 0) {
      return cb({ name: 'ValidationError', message: 'Team already exist' });
    } else {
      team.save(cb);
    }
  });
}

exports.addCodersToTeam = function (game, callback) {

  const { home_team, away_team, home_team_coder, away_team_coder } = game;
  Team.update({ _id: { $in: [home_team, away_team] } }, { $addToSet: { coders: [home_team_coder, away_team_coder] } }, { multi: true }, function (err, data) {
    return callback(data);
  });
}


exports.update = function (id, params, cb) {

  Team.findOneAndUpdate({ _id: id }, { $set: params }, { new: true, runValidators: true }, cb);
}

exports.getById = function (id, cb) {
  Team.findById(id, cb);
}

exports.getPlayers = function (id, cb) {
  TeamMember.getByTeam(id, cb);
}

exports.findMany = function (query, cb) {
  Team.find(query, cb)
}

exports.remove = function (id, cb) {
  Team.findById(id, function (err, team) {
    if (err) cb(err);
    team.remove();
    cb(null);
  })
}

exports.countAll = function (search, callback) {
  let searchParams = {};
  if (search) {
    var search = new RegExp(search);
    searchParams = { $or: [{ name: search }, { coach: search }, { stadium: search }, { location: search }] };
  }
  Team.count(searchParams, function (err, counter) {
    callback(counter);
  });
}

exports.all = function (params, cb) {

  var sort = {},
    searchParams = {};

  if (params.sort_by) {
    sort[params.sort_by] = params.sort_type == 'desc' ? -1 : 1;
  }
  if (params.s) {
    var search = new RegExp(params.s);
    searchParams = { $or: [{ name: search }, { coach: search }, { stadium: search }, { location: search }] };
  }

  var offset = parseInt(params.offset),
    limit = parseInt(params.limit);

  Team.find(searchParams)
    .populate('coach')
    .populate('location')
    .sort(sort)
    .skip(offset * limit)
    .limit(limit)
    .exec(cb);
}

exports.removeAll = function (params, cb) {
  Team.remove(params, cb);
}