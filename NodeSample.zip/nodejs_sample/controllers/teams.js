var express = require('express');
var router = express.Router();
var passport = require('passport');
var configJwt = require('../config/jwt');
var expressJwt = require('express-jwt');
var authenticate = expressJwt({ secret: configJwt.secret });
var adminRequest = require('../middlewares/helpers').adminRequest;
var messages = require('../config/messages').currentLocalization();
var Team = require('../models/team');
var TeamPlayers = require('../models/teamPlayers');
var TeamSeason = require('../models/teamSeason');
var Season = require('../models/season');

const fs = require('fs');

router.post('/api/v1/teams', authenticate, adminRequest, function (req, res) {

	Team.create(req.body, function (err, team) {
		if (err) {
			if (err.name == 'ValidationError') {
				return res.status(400).json(err);
			} else {
				return res.status(500).json(err);
			}
		}
		res.json({ team: team, message: messages.saved_success })
	})
});

router.get('/api/v1/teams', authenticate, function (req, res) {
	Team.all(req.query, function (err, data) {
		Team.countAll(req.query.s, function (counter) {
			if (!counter) {
				counter = 0;
			}
			res.json({ items: data, itemsCounter: counter });
		})
	})
});

router.get('/api/v1/teams/:id', authenticate, function (req, res) {
	Team.getById(req.params.id, function (err, team) {
		if (!team) {
			return res.status(400).json({ message: messages.not_found });
		}
		res.json(team)
	})
});

router.get('/api/v1/teams/:id/players', authenticate, function (req, res) {
	var team = req.params.id;
	var season = req.query.season;

	TeamSeason.getTeamSeasonByTeamID(team, season, function (err, teamSeason) {
		if (teamSeason && teamSeason._id) {
			var teamSeasonId = teamSeason._id;

			TeamPlayers.getTeamPlayers(teamSeasonId, function (err, players) {
				if (err) return res.status(500).json(err);
				res.json(players)
			})
		} else {
			console.error('not found');
			res.json([]);
		}

	})
});

router.post('/api/v1/teams/image/', authenticate, function (req, res, next) {

	let sampleFile = req.files.file;
	let username = req.query.name;
	let fileName = `${username}-${sampleFile.name}`;
	let oldImage = req.query.oldImage;
	// var extension = path.extname(file);

	// mv() method to place the file somewhere on your server
	let imageUrl = `./public/images/${fileName}`;
	sampleFile.mv(imageUrl, function (err) {
		if (err) return res.status(500).json(err);


		if (oldImage != 'none') {
			// delete file method
			fs.unlink('./public/images/' + oldImage, (err) => {
				console.log('successfully deleted ' + oldImage.toString());
				return res.json({ name: fileName, message: 'Image was upload' });
			});
			// delete file method
		} else {
			return res.json({ name: fileName, message: 'Image was upload' });
		}
	});

});

router.delete('/api/v1/teams/image/', authenticate, function (req, res, next) {

	let image = req.body.imageName;

	fs.unlink('./public/images/' + image, (err) => {
		console.log('successfully deleted ' + image.toString());
		return res.json({ message: 'Image was deleted' });
	});

});

router.put('/api/v1/teams/:id', authenticate, adminRequest, function (req, res) {
	Team.update(req.params.id, req.body, function (err, team) {
		if (err) {
			if (err.name == 'ValidationError') {
				return res.status(400).json({ message: err.errors.name.message });
			} else {
				return res.status(500).json(err);
			}
		}
		res.json({ team: team, message: messages.saved_success });
	})
});

router.delete('/api/v1/teams/:id', authenticate, adminRequest, function (req, res) {
	Team.remove(req.params.id, function (err) {

		Season.removeTeam(req.params.id, function(err, data){

		TeamSeason.deleteBySeasonOrTeamId({ team: req.params.id }, function (err, data) {
			res.json({ message: messages.deleted_success });
		})
	})
})
});


module.exports = router;