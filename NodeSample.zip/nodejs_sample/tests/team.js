//During the test the env variable is set to test
process.env.NODE_ENV = 'test';

let mongoose = require("mongoose");
let helper = require('./helpers/helper');
let Team = require('../models/team');

//Require the dev-dependencies
let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../app');
let should = chai.should();

chai.use(chaiHttp);

describe('Teams', () => {
	let token = null;
  let admin = {
    username: 'admin',
    password: 'Aa123456',
    role: 'admin',
    email: 'admin@admin.com'
  };

  let competition = {
    title: 'FIFA',
    type: 'International',
    players_gender: 'male',
    season: '2017 - 2018'
  };
  let location = {
    city: 'London',
    country: 'Great Britain',
    state: 'state',
    address: 'aaa',
    zip: '11111'
  };

  let team = {
		'name': 'Manchester United'
	};

  let teamMember = {
    type: 'player',
    first_name: 'David',
    last_name: 'de Gea',
    is_captain: false,
    weight: 76,
    height: 192,
    date_of_birth: new Date(1990, 11, 7),
    nationality: 'Spain',
    first_nationality: 'Spain'
  };
  let stadium = {
    'title': 'Wembley Stadium',
    'capacity': 90000,
    'width': 69,
    'length': 105,
    'opened_at': new Date(1923, 1, 1),
    'location': 'London'
  };

  before((done) => {
  	helper.createAdmin(admin)
      .then(() => helper.createStadium(stadium))
      .then(() => helper.createLocation(location))
      .then(() => helper.createTeamMember(teamMember))
      .then(() => helper.createCompetition(competition))
      .then(() => {
        Team.removeAll({}, done);
      })
  });

  describe('/POST login admin', () => {
  	it('it should login admin', (done) => {
      chai.request(server)
        .post('/api/v1/login')
        .send(admin)
        .end((err, res) => {
        	if (err) return done(err);
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('id', admin.id);
          res.body.should.have.property('token');
          token = res.body.token;
          done();
        });
    });
  });

  describe('/POST team', () => {
  	

    it('it should not create team without title', (done) => {
      chai.request(server)
        .post('/api/v1/teams')
        .send({})
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(400);
          res.body.should.be.a('object');
          res.body.should.have.property('message');
          done();
        });
    });

    it('it should create team', (done) => {

      chai.request(server)
        .post('/api/v1/teams')
        .send(team)
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('team');
          res.body.should.have.property('message');
          res.body.team.should.have.property('_id');
          team.id = res.body.team._id;
          res.body.team.should.have.property('name', team.name);
          done();
        });
    });
  });


  describe('/GET teams', () => {
  	it('it should get teams', (done) => {

      chai.request(server)
        .get('/api/v1/teams')
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('items');
          res.body.items.should.be.a('array');
          res.body.should.have.property('itemsCounter', 1);
          res.body.items.length.should.be.eql(1);
          done();
        });
    });

    it('it should get team by id', (done) => {

      chai.request(server)
        .get('/api/v1/teams/' + team.id)
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('_id', team.id);
          done();
        });
    });

  })

  describe('/PUT team', () => {

    it('it should not update team without name', (done) => {
      team.name = '';
      chai.request(server)
        .put('/api/v1/teams/' + team.id)
        .send(team)
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(400);
          res.body.should.be.a('object');
          res.body.should.have.property('message');
          done();
        });
    });

  	it('it should update team', (done) => {
  		team.name = 'Liverpool';
      chai.request(server)
        .put('/api/v1/teams/' + team.id)
        .send(team)
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('team');
          res.body.should.have.property('message');
          res.body.team.should.have.property('_id', team.id);
          res.body.team.should.have.property('name', team.name);
          done();
        });
    });


    it('it should update team stadium, location, coach', (done) => {
      team.coach = teamMember.id;
      team.location = location.id;
      team.stadium = stadium.id;
      chai.request(server)
        .put('/api/v1/teams/' + team.id)
        .send(team)
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('team');
          res.body.should.have.property('message');
          res.body.team.should.have.property('_id', team.id);
          res.body.team.should.have.property('coach', teamMember.id);
          res.body.team.should.have.property('location', location.id);
          res.body.team.should.have.property('stadium', stadium.id);
          done();
        });
    });

    
  });

  describe('Team competition', () => {
    it('it should create team competition', (done) => {
      chai.request(server)
        .post('/api/v1/teams/' + team.id + '/competitions/' + competition.id)
        .send({ year: 2018 })
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('team_competition');
          res.body.should.have.property('message');
          res.body.team_competition.should.have.property('team', team.id);
          res.body.team_competition.should.have.property('competition', competition.id);
          res.body.team_competition.should.have.property('year', 2018);
          res.body.team_competition.year.should.be.a('number');
          done();
        });
    });

    it('it should get team competitions', (done) => {
      chai.request(server)
        .get('/api/v1/teams/' + team.id + '/competitions')
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('array');
          res.body.length.should.be.eql(1);
          res.body[0].should.have.property('competition', competition.id);
          res.body[0].should.have.property('year', 2018);
          done();
        });
    });

    it('it should remove team competition', (done) => {
      chai.request(server)
        .delete('/api/v1/teams/' + team.id + '/competitions/' + competition.id)
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('message');
          done();
        });
    });
  })

  describe('/DELETE team', () => {
  	it('it should delete team', (done) => {
      chai.request(server)
        .delete('/api/v1/teams/' + team.id)
        .send(team)
        .set('Authorization', 'Bearer ' + token)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('message');
          done();
        });
    });
  })
})