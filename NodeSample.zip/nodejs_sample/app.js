var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var mongoose = require('mongoose');
var passport = require('passport');
var router = express.Router();
var expressJwt = require('express-jwt');  
var cors = require('cors');

// for images
const fileUpload = require('express-fileupload');
// for images

var configDB = require('./config/database.js');



if (process.env.APP_ENV === 'production') {
  mongoose.connect(configDB.productionUrl); // connect to our database
} else {
  mongoose.connect(configDB.url); // connect to our database
}


var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());
app.use(cors());

// For images start
app.use(fileUpload({limits: { fileSize: 50 * 1024 * 1024 }}));
// For images end

router.get('/', function (req, res) {
  res.send('Working!');
});

require('./config/passport')(passport);
// app.use(require('./middlewares/users'))
app.use(require('./controllers/users'));
app.use(require('./controllers/auth'));
app.use(require('./controllers/permissions'));
app.use(require('./controllers/actions'));
app.use(require('./controllers/attributes'));
app.use(require('./controllers/hotkeys'));
app.use(require('./controllers/weatherConditions'));
app.use(require('./controllers/fieldConditions'));
app.use(require('./controllers/phases'));
app.use(require('./controllers/rounds'));
app.use(require('./controllers/stadiums'));
app.use(require('./controllers/team_members'));
app.use(require('./controllers/teams'));
app.use(require('./controllers/locations'));
app.use(require('./controllers/formations'));
app.use(require('./controllers/competitions'));
app.use(require('./controllers/games'));
app.use(require('./controllers/gamePlayers'));
app.use(require('./controllers/matchdays'));
app.use(require('./controllers/nationalities'));
app.use(require('./controllers/gameTeams'));
app.use(require('./controllers/events'));
app.use(require('./controllers/cloneTeamsFromPhases'));
app.use(require('./controllers/referees'));
app.use(require('./controllers/transfers'));
app.use(require('./controllers/seasons'));

app.use(function (err, req, res, next) {
  if (err.name === 'UnauthorizedError') {
    res.status(401).json({ status: 'Invalid token.'});
  }
});
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
