var messages = require('../config/messages').currentLocalization();
var User =  require('../models/user');

var adminRequest = function (req, res, next) {
	if (req.user.role != 'admin') {
		return res.status(403).json({ message: messages.admin_access });
	}
	next();
};

var findUser = function (req, res, next) {
	User.findById(req.params.id, function (err, user) {
		if (err) {
			if (err.name == 'CastError') {
				return res.status(400).json({ message: messages.user_not_found });
			}
			return res.status(400).json(err);
		}
		req.foundedUser = user;
		next();
	})
}


module.exports = {
	adminRequest: adminRequest,
	findUser: findUser
}